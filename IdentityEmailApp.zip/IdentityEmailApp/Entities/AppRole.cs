﻿using Microsoft.AspNetCore.Identity;

namespace IdentityEmailApp.Entities
{
    public class AppRole: IdentityRole<int>
    {
    }
}
